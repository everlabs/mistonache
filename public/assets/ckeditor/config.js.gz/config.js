CKEDITOR.editorConfig = function (config) {
  config.filebrowserFlashUploadUrl = '/ckeditor/attachment_files';
  config.filebrowserImageUploadUrl = '/ckeditor/pictures';
  config.filebrowserUploadUrl = '/ckeditor/attachment_files';
};
